import 'package:flutter/material.dart';

import '../emergency/emergency_screen.dart';
import '../role/role_portal_screen.dart';

class AccessModeScreen extends StatelessWidget {
  final String emergencyContact;

  const AccessModeScreen({
    super.key,
    required this.emergencyContact,
  });

  static const Color primary = Color(0xFF00796B);
  static const Color textPrimary = Color(0xFF102A43);
  static const Color textSecondary = Color(0xFF62758A);
  static const Color background = Color(0xFFF7FAF9);

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      appBar: AppBar(
        title: const Text('Login As'),
        backgroundColor: background,
        elevation: 0,
      ),
      body: SafeArea(
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF00695C), Color(0xFF00A878)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(25),
              ),
              child: const Row(
                children: [
                  Icon(Icons.lock_open_rounded, color: Colors.white, size: 42),
                  SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Choose your access', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800)),
                        SizedBox(height: 5),
                        Text('Different dashboards for patients and healthcare partners.', style: TextStyle(color: Colors.white70, height: 1.35)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _modeCard(
              context,
              icon: Icons.person_rounded,
              title: 'User',
              subtitle: 'Access appointments, records, medicines, AI and family health.',
              color: const Color(0xFF2878E8),
              onTap: () => Navigator.pop(context),
            ),
            _modeCard(
              context,
              icon: Icons.local_hospital_rounded,
              title: 'Hospital',
              subtitle: 'Manage hospital services, appointments, OPD and patient flow.',
              color: const Color(0xFF00A878),
              onTap: () => _open(context, const RolePortalScreen(role: 'Hospital')),
            ),
            _modeCard(
              context,
              icon: Icons.science_rounded,
              title: 'Lab Shop',
              subtitle: 'Manage test bookings, sample collection and reports.',
              color: const Color(0xFF7653D6),
              onTap: () => _open(context, const RolePortalScreen(role: 'Lab Shop')),
            ),
            const SizedBox(height: 8),
            _modeCard(
              context,
              icon: Icons.emergency_rounded,
              title: 'Emergency Guest Mode',
              subtitle: 'No login required. Quickly reach emergency help and calling tools.',
              color: const Color(0xFFD94A42),
              onTap: () => _open(
                context,
                EmergencyScreen(emergencyContact: emergencyContact),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Emergency Guest Mode is designed for quick access; it does not replace professional emergency care.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: textSecondary, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _modeCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: const BorderSide(color: Color(0xFFE0ECE8)),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.all(17),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: color.withOpacity(.10),
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Icon(icon, color: color, size: 29),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: textPrimary)),
                    const SizedBox(height: 5),
                    Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.35, color: textSecondary)),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: color),
            ],
          ),
        ),
      ),
    );
  }
}
