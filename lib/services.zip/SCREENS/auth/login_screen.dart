import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../services/user_service.dart';
import '../home/home_dashboard.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _phoneController =
      TextEditingController();

  String _selectedRole = 'Patient';

  bool _isGuestLoading = false;

  final List<Map<String, dynamic>> _roles = const [
    {
      'name': 'Patient',
      'subtitle': 'Access your care & records',
      'icon': Icons.person_rounded,
      'color': Color(0xFF2878E8),
      'bg': Color(0xFFEAF2FF),
    },
    {
      'name': 'Hospital',
      'subtitle': 'Manage hospital services',
      'icon': Icons.local_hospital_rounded,
      'color': Color(0xFF0F766E),
      'bg': Color(0xFFE7F8F4),
    },
    {
      'name': 'Lab Shop',
      'subtitle': 'Manage test bookings',
      'icon': Icons.biotech_rounded,
      'color': Color(0xFF7653D6),
      'bg': Color(0xFFF2EDFF),
    },
  ];

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  // =====================================================
  // SEND OTP
  // =====================================================

  void _sendOtp() {
    final phoneNumber = _phoneController.text.trim();

    if (phoneNumber.length != 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter a valid 10-digit mobile number',
          ),
        ),
      );
      return;
    }

    Navigator.of(context).push(
      PageRouteBuilder(
        transitionDuration:
            const Duration(milliseconds: 400),
        pageBuilder: (_, animation, __) => OtpScreen(
          phoneNumber: phoneNumber,
        ),
        transitionsBuilder:
            (_, animation, __, child) {
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.08, 0),
                end: Offset.zero,
              ).animate(
                CurvedAnimation(
                  parent: animation,
                  curve: Curves.easeOutCubic,
                ),
              ),
              child: child,
            ),
          );
        },
      ),
    );
  }

  // =====================================================
  // EMERGENCY GUEST MODE
  // =====================================================

  Future<void> _guestMode() async {
    if (_isGuestLoading) return;

    setState(() {
      _isGuestLoading = true;
    });

    try {
      // Create temporary guest session
      await UserService.loginAsGuest();

      if (!mounted) return;

      // Directly open Home Dashboard.
      //
      // No:
      // - Name
      // - Age
      // - Gender
      // - City
      // - Blood Group
      // - Emergency Contact
      //
      // required for Guest Mode.

      Navigator.of(context).pushAndRemoveUntil(
        PageRouteBuilder(
          transitionDuration:
              const Duration(milliseconds: 450),
          pageBuilder: (_, animation, __) {
            return HomeDashboard(
              userName: '',
              userAge: '',
              userGender: '',
              userCity: '',
              bloodGroup: '',
              emergencyContact: '',
            );
          },
          transitionsBuilder:
              (_, animation, __, child) {
            return FadeTransition(
              opacity: animation,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, 0.06),
                  end: Offset.zero,
                ).animate(
                  CurvedAnimation(
                    parent: animation,
                    curve: Curves.easeOutCubic,
                  ),
                ),
                child: child,
              ),
            );
          },
        ),
        (route) => false,
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _isGuestLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to enter Emergency Guest Mode. Please try again.',
          ),
        ),
      );
    }
  }

  // =====================================================
  // BUILD
  // =====================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {},
          child: SingleChildScrollView(
            physics:
                const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(
              20,
              18,
              20,
              30,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                // =================================================
                // HEADER
                // =================================================

                Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      padding:
                          const EdgeInsets.all(9),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(15),
                        border: Border.all(
                          color:
                              const Color(0xFFE4ECEA),
                        ),
                      ),
                      child: Image.asset(
                        'assets/icon/app_logo.png',
                        fit: BoxFit.contain,
                      ),
                    ),

                    const SizedBox(width: 12),

                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            'JAN AROGYA',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight:
                                  FontWeight.w900,
                              color:
                                  AppTheme.textPrimary,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'One platform. Complete care.',
                            style: TextStyle(
                              fontSize: 12,
                              color:
                                  AppTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),

                    IconButton(
                      onPressed: _isGuestLoading
                          ? null
                          : () =>
                              Navigator.maybePop(
                                context,
                              ),
                      icon: const Icon(
                        Icons.close_rounded,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 30),

                // =================================================
                // WELCOME CARD
                // =================================================

                Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    gradient:
                        const LinearGradient(
                      colors: [
                        Color(0xFFE8F8F4),
                        Color(0xFFF4FBFA),
                      ],
                    ),
                    borderRadius:
                        BorderRadius.circular(26),
                    border: Border.all(
                      color:
                          const Color(0xFFD3EEE8),
                    ),
                  ),
                  child: const Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons
                            .health_and_safety_rounded,
                        color: AppTheme.primary,
                        size: 34,
                      ),

                      SizedBox(height: 16),

                      Text(
                        'Welcome back',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight:
                              FontWeight.w900,
                          color:
                              AppTheme.textPrimary,
                        ),
                      ),

                      SizedBox(height: 7),

                      Text(
                        'Sign in securely to manage appointments, medicines, records and family healthcare.',
                        style: TextStyle(
                          fontSize: 14,
                          height: 1.5,
                          color:
                              AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // =================================================
                // LOGIN ROLE
                // =================================================

                const Text(
                  'Login as',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.textPrimary,
                  ),
                ),

                const SizedBox(height: 12),

                SizedBox(
                  height: 118,
                  child: ListView.separated(
                    scrollDirection:
                        Axis.horizontal,
                    itemCount: _roles.length,
                    separatorBuilder:
                        (_, __) =>
                            const SizedBox(
                      width: 10,
                    ),
                    itemBuilder:
                        (_, index) {
                      final role =
                          _roles[index];

                      final bool selected =
                          _selectedRole ==
                              role['name'];

                      return GestureDetector(
                        onTap:
                            _isGuestLoading
                                ? null
                                : () {
                                    setState(() {
                                      _selectedRole =
                                          role['name']
                                              as String;
                                    });
                                  },
                        child:
                            AnimatedContainer(
                          duration:
                              const Duration(
                            milliseconds: 180,
                          ),
                          width: 154,
                          padding:
                              const EdgeInsets.all(
                            14,
                          ),
                          decoration:
                              BoxDecoration(
                            color: selected
                                ? role['bg']
                                    as Color
                                : Colors.white,
                            borderRadius:
                                BorderRadius
                                    .circular(
                              20,
                            ),
                            border: Border.all(
                              color: selected
                                  ? role['color']
                                      as Color
                                  : const Color(
                                      0xFFE5EAF0,
                                    ),
                              width: selected
                                  ? 1.5
                                  : 1,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                            children: [
                              Icon(
                                role['icon']
                                    as IconData,
                                color: role['color']
                                    as Color,
                                size: 27,
                              ),

                              const Spacer(),

                              Text(
                                role['name']
                                    as String,
                                style:
                                    const TextStyle(
                                  fontWeight:
                                      FontWeight
                                          .w800,
                                  color:
                                      AppTheme
                                          .textPrimary,
                                ),
                              ),

                              const SizedBox(
                                height: 2,
                              ),

                              Text(
                                role['subtitle']
                                    as String,
                                maxLines: 1,
                                overflow:
                                    TextOverflow
                                        .ellipsis,
                                style:
                                    const TextStyle(
                                  fontSize: 10.5,
                                  color:
                                      AppTheme
                                          .textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),

                const SizedBox(height: 24),

                // =================================================
                // MOBILE NUMBER
                // =================================================

                const Text(
                  'Mobile number',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),

                const SizedBox(height: 9),

                TextField(
                  controller:
                      _phoneController,
                  enabled: !_isGuestLoading,
                  keyboardType:
                      TextInputType.phone,
                  maxLength: 10,
                  decoration:
                      const InputDecoration(
                    counterText: '',
                    prefixIcon: Padding(
                      padding:
                          EdgeInsets.only(
                        left: 18,
                        right: 10,
                      ),
                      child: Center(
                        widthFactor: 1,
                        child: Text(
                          '+91',
                          style: TextStyle(
                            fontWeight:
                                FontWeight
                                    .w800,
                            color:
                                AppTheme
                                    .textPrimary,
                          ),
                        ),
                      ),
                    ),
                    prefixIconConstraints:
                        BoxConstraints(
                      minWidth: 66,
                    ),
                    hintText:
                        'Enter 10-digit mobile number',
                  ),
                ),

                const SizedBox(height: 16),

                // =================================================
                // CONTINUE BUTTON
                // =================================================

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed:
                        _isGuestLoading
                            ? null
                            : _sendOtp,
                    icon: const Icon(
                      Icons
                          .arrow_forward_rounded,
                    ),
                    label: Text(
                      'Continue as $_selectedRole',
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // =================================================
                // EMERGENCY GUEST MODE
                // =================================================

                SizedBox(
                  width: double.infinity,
                  child:
                      OutlinedButton.icon(
                    onPressed:
                        _isGuestLoading
                            ? null
                            : _guestMode,
                    icon: _isGuestLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child:
                                CircularProgressIndicator(
                              strokeWidth: 2.2,
                            ),
                          )
                        : const Icon(
                            Icons
                                .emergency_rounded,
                          ),
                    label: Text(
                      _isGuestLoading
                          ? 'Opening Emergency Mode...'
                          : 'Emergency Guest Mode',
                    ),
                  ),
                ),

                const SizedBox(height: 18),

                // =================================================
                // TERMS
                // =================================================

                Center(
                  child: Text(
                    'OTP verification keeps your account protected.\nBy continuing, you agree to our Terms & Privacy Policy.',
                    textAlign:
                        TextAlign.center,
                    style: TextStyle(
                      fontSize: 11.5,
                      height: 1.45,
                      color:
                          Colors.grey.shade600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}